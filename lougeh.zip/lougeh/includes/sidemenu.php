<div class="col-sm-2 col-lg-2">
    <div class="sidebar-nav">
        <div class="nav-canvas">
            <div class="nav-sm nav nav-stacked">

            </div>
            <ul class="nav nav-pills nav-stacked main-menu">
                <li class="nav-header">Main</li>
                <li><a class="ajax-link" href="index.php"><i class="glyphicon glyphicon-home"></i><span> Transactions</span></a>
                </li>
                <li><a class="ajax-link" href="items.php"><i class="glyphicon glyphicon-tasks"></i><span> Items</span></a>
                </li>
                <li><a class="ajax-link" href="customers.php"><i class="glyphicon glyphicon-user"></i><span> Customers</span></a>
                </li>
                <li><a class="ajax-link" href="suppliers.php"><i class="glyphicon glyphicon-plus"></i><span> Suppliers</span></a>
                </li>
            </ul>
            
        </div>
    </div>
</div>