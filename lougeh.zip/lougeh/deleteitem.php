<?php
	include('includes/config.php');

	$ntid = $_REQUEST['ntid'];

	mysqli_query($conn, "DELETE FROM items WHERE barcode = '$ntid'");

	header("location:newitem.php")

?>