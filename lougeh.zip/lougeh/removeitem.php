<?php
	include('includes/config.php');

	$ntid = $_REQUEST['ntid'];

	mysqli_query($conn, "DELETE FROM newtransaction WHERE newtransaction_id = $ntid");

	header("location:newtransaction.php")

?>