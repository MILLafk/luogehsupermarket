<?php
    session_start();
    include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <title>Lou Geh Supermarket Sales</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <link rel="shortcut icon" href="img/favicon.ico">

</head>

<body>
<!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"> 
                <span>Lou Geh</span></a>
        </div>
    </div>
    <!-- topbar ends -->
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <?php 
            include('includes/sidemenu.php');
        ?>
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div class="col-md-12">
                <ul class="breadcrumb">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="suppliers.php">Suppliers</a>
                    </li>
                    <li>
                        <a href="newsupplier.php">New Supplier</a>
                    </li>
                     <li>
                        <a href="editsupplier.php">Edit Supplier</a>
                    </li>
                </ul>

            </div>

            <br>
           
<div class="row">
    <div class="box col-md-4">
        <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-edit"></i> Edit Supplier</h2>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">

                         <?php

                            function convert($toConvert){
                                return number_format($toConvert, 2);
                            }

                            $cid = $_REQUEST['cid'];
                            $query2 = mysqli_query($conn, "SELECT * FROM suppliers WHERE supplier_id = '$cid'");
                            $row2 = mysqli_fetch_array($query2);
                            $cname2 = $row2['company_name'];
                            $address2 = $row2['company_address'];
                            $contact2 = $row2['company_contact_number'];

                            if (isset($_POST['save'])) {
                               $cname = $_POST['cname'];
                               $address = $_POST['address'];
                               $contact = $_POST['contact'];
                               
                                mysqli_query($conn, "UPDATE suppliers set company_name = '$cname', company_address = '$address', company_contact_number = '$contact' WHERE supplier_id = '$cid'");

                                echo '<meta http-equiv="refresh" content="0; URL=http://localhost/lougeh/newsupplier.php">';


                            }
                        ?>
                        <form method="POST">
                            <div class="col-md-12">
                                <label>Company Name:</label>
                                <input type="text" name="cname" class="form-control" placeholder="Customer's First name" required="" value="<?php echo $cname2; ?>">
                            </div>
                            <div class="col-md-12"><br>
                                <label>Address:</label>
                                <input type="text" name="address" class="form-control" placeholder="Customer's Address" required=""
                                 value="<?php echo $address2; ?>">
                            </div>
                            <div class="col-md-12"><br>
                                <label>Contact Number:</label>
                                <input type="text" name="contact" class="form-control" placeholder="Customer's Contact Number" required="" value="<?php echo $contact2; ?>">
                            </div>
                            <div class="col-md-12"><br><br>
                                <button name="save" class="btn btn-primary col-md-12"><i class="glyphicon glyphicon-check"></i> Save</button>
                            </div>
                        </form>
                    </div>
                </div>
                <span style="color: white">Ender</span>
            </div>
        </div>
    </div>
    <div class="box col-md-8">
        <div class="box-inner">
            <div class="box-header well">
                <div class="col-md-10">
                    <h2><i class="glyphicon glyphicon-info-sign"></i> Suppliers</h2>
                </div>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">
                        <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
                        <thead>
                        <tr>
                            <th width="10">Supplier ID</th>
                            <th>Company Name</th>
                            <th>Address</th>
                            <th width="5">Contact Number</th>
                            <th width="5">Options</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                    
                                $query = mysqli_query($conn, "SELECT * FROM suppliers");
                                $numrows = mysqli_num_rows($query);
                                if ($numrows != 0) {
                                
                                    while ($row = mysqli_fetch_array($query)) {
                                        $supplier_id = $row['supplier_id'];
                                        $company_name = $row['company_name'];
                                        $address = $row['company_address'];
                                        $contact = $row['company_contact_number'];

                                        echo "<tr>";
                                        echo "<td>$supplier_id</td>";
                                        echo "<td>$company_name</td>";
                                        echo "<td>$address</td>";
                                        echo "<td>$contact</td>";
                                        echo "
                                        <td>
                                            <a href='editsupplier.php?cid=$supplier_id' class='btn btn-primary btn-sm'><i class='glyphicon glyphicon-edit'></i></a>
                                            <a class='btn btn-danger btn-sm' onClick=\"javascript: return confirm('Remove supplier from database?');\" href='deletesupplier.php?cid=$supplier_id'><i class='glyphicon glyphicon-remove'></i></a>
                                        </td>
                                        ";
                                        echo "</tr>";

                                    }
                                }
                                else{
                            ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php } ?>
                
                        </tbody>
                        </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div><!--/.fluid-container-->

<!-- external javascript -->



<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>
<?php
    include('modals.php');
?>

</body>
</html>
