<?php
	session_start();
	include('includes/config.php');

	$_SESSION['trantype'] = '';
	$_SESSION['id'] = '';
	$_SESSION['type'] = '';
	$_SESSION['curbar'] = '';
	mysqli_query($conn, 'DELETE FROM newtransaction');

	header('location:newtransaction.php');

?>