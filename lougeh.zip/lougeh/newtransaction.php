<?php
    session_start();
    include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <title>Lou Geh Supermarket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <link rel="shortcut icon" href="img/favicon.ico">

</head>

<body>
<!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"> 
                <span>Lou Geh</span></a>
        </div>
    </div>
    <!-- topbar ends -->
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <?php 
            include('includes/sidemenu.php');
        ?>
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div class="col-md-12">
                <ul class="breadcrumb">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="index.php">Transactions</a>
                    </li>
                    <li>
                        <a href="newtransaction.php">New Transaction</a>
                    </li>
                </ul>

            </div>

            <br>
           
<script type="text/javascript">
    function getTotal(){
        var quantity = document.getElementById("quantity").value;
        var cost = document.getElementById("cost").value;
        var total = document.getElementById("total");

        total.value = quantity * cost;
    }
</script>
<div class="row">
    <div class="box col-md-4">
        <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-plus"></i> Add Item</h2>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">

                         <?php

                            function convert($toConvert){
                                return number_format($toConvert, 2);
                            }

                            if (isset($_POST['add'])) {
                                $barcode = $_POST['barcode'];
                                $desc = $_POST['descr'];
                                $quantity = $_POST['quantity'];
                                $costperunit = $_POST['cost'];
                                $total = $_POST['total'];
                                if (isset($_SESSION['trantype']) && $_SESSION['trantype'] == '') {
                                    $trantype = $_POST['trantype'];
                                    $_SESSION['trantype'] = $trantype;
                                }

                                $_SESSION['curbar'] = '';

                               
                                mysqli_query($conn, "INSERT INTO newtransaction (barcode, description, quantity, cost_per_unit, total) 
                                        VALUES ('$barcode', '$desc', $quantity, $costperunit, $total)");

                            }
                        ?>
                        <form method="POST">
                           
                            <div class="col-md-9">
                            <?php
                                if (isset($_SESSION['id']) && $_SESSION['id'] != '') {
                                    $id = $_SESSION['id'];

                                    if ($_SESSION['type'] == 'customer') {
                                        $queryname = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = '$id'");
                                        $row = mysqli_fetch_array($queryname);
                                        $name = $row['customer_firstname']." ".$row['customer_mi'].". ".$row['customer_lastname'];
                                    }
                                    else if ($_SESSION['type'] == 'supplier') {
                                        $queryname = mysqli_query($conn, "SELECT * FROM suppliers WHERE supplier_id = '$id'");
                                        $row = mysqli_fetch_array($queryname);
                                        $name = $row['company_name'];
                                    }

                            ?>
                                    <label>Customer/Supplier:</label>
                                    <input type="text" class="form-control" name="customer" value="<?php echo $name; ?>" > 
                            <?php
                                }
                                else{
                            ?>
                                    
                                        <label>Customer/Supplier:</label>
                                        <input type="text" name="customer" class="form-control" placeholder="Customer/Supplier Name" required="">
                                    
                            <?php } ?>
                            </div>
                            <div class="col-md-3">
                                <label style="color: white">Search</label>
                                <button href="selectcustomer.php"
                                  type="button"
                                  data-toggle="modal" 
                                  data-target="#selectCustomer"
                                  class="btn btn-default glyphicon glyphicon-search col-md-12"
                                  title="Select Customer/Supplier"
                                  name="select">
                              </button>
                            </div>
                             
                            <?php 
                                $barvalue = "";
                                $descvalue = "";
                                $costvalue = "";

                                if (isset($_SESSION['curbar']) && $_SESSION['curbar'] != '') {
                                    $curbar2 = $_SESSION['curbar'];
                                    $curquery = mysqli_query($conn, "SELECT * FROM items WHERE barcode = '$curbar2'");
                                    $currow = mysqli_fetch_array($curquery);
                                    $barvalue = $currow['barcode'];
                                    $descvalue = $currow['product_description'];
                                    $costvalue = $currow['cost_per_unit'];
                                }
                            ?>
                            <div class="col-md-9"><br>
                                <label>Barcode:</label>
                                <input type="text" name="barcode" class="form-control" placeholder="Barcode" required="" value="<?php echo $barvalue; ?>">
                            </div>
                            <div class="col-md-3"><br>
                                <label style="color: white">Search</label>
                                <button href="selectitem.php"
                                  type="button"
                                  data-toggle="modal" 
                                  data-target="#selectItem"
                                  class="btn btn-default glyphicon glyphicon-search col-md-12"
                                  title="Select Item"
                                  name="selectitem">
                              </button>
                            </div>
                            <div class="col-md-12"><br>
                                <label>Item Description:</label>
                                <input type="text" name="descr" class="form-control" placeholder="Item Description" required="" value="<?php echo $descvalue; ?>">
                            </div>
                            <div class="col-md-6"><br>
                                <label>Quantity:</label>
                                <input type="number" name="quantity" id="quantity" class="form-control" min="1" placeholder="Quantity" onchange="getTotal()" required="">
                            </div>
                            <div class="col-md-6"><br>
                                <label>Cost/unit:</label>
                                <input type="number" name="cost" id="cost" class="form-control" min="0" step=".01"  placeholder="Cost per Unit" onchange="getTotal()" required="" value="<?php echo $costvalue; ?>">
                            </div>
                            <div class="col-md-12"><br>
                                <?php
                                    if (isset($_SESSION['trantype']) && $_SESSION['trantype'] != '') {
                                ?>
                                        <input type="text" class="form-control" name="trantype" value="<?php echo $_SESSION['trantype']; ?>" disabled> 
                                <?php
                                    }
                                    else{
                                ?>
                                        <label>Transaction Type:</label>
                                        <select class="form-control" name="trantype">
                                            <option>Sales</option>
                                            <option>Delivery</option>
                                        </select>
                                <?php } ?>
                            </div>
                            <div class="col-md-12"><br>
                                <label>Total Amount:</label>
                                <input type="number" name="total" id="total" class="form-control" min="0" step=".01" placeholder="Total Amount">
                            </div>

                            <div class="col-md-5"><br><br>
                                <button name="add" class="btn btn-primary col-md-12"><i class="glyphicon glyphicon-plus"></i> Add Item</button>
                            </div>
                        </form>
                    </div>
                </div>
                <span style="color: white">Ender</span>
            </div>
        </div>
    </div>
    <div class="box col-md-8">
        <div class="box-inner">
            <div class="box-header well">
                
                <div class="col-md-10">
                    <h2><i class="glyphicon glyphicon-info-sign"></i> Items</h2>
                </div>
                <?php
                    if (isset($_SESSION['trantype']) && $_SESSION['trantype'] != '') {
                ?>
                <div class="col-md-1">
                    <a href="savetransaction.php" class="btn btn-primary btn-xs" onclick="return confirm('Save transaction?')"><i class="glyphicon glyphicon-ok"></i> Save</a><br>
                </div>
                <div class="col-md-1">
                    <a href="canceltransaction.php" class="btn btn-default btn-xs" onclick="return confirm('Cancel transaction?')"><i class="glyphicon glyphicon-remove"></i> Cancel</a><br>
                </div>
                <?php } ?>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">
                        <table class="table table-striped table-bordered bootstrap-datatable  responsive">
                        <thead>
                        <tr>
                            <th>Barcode</th>
                            <th>Item Description</th>
                            <th width="5">Qty</th>
                            <th>Cost/unit</th>
                            <th>Total Item Cost</th>
                            <th width="5">Remove</th>
                        </tr>
                        </thead>
                        <tbody>
                    
                            <?php
                                $query = mysqli_query($conn, "SELECT * FROM newtransaction");
                                $numrows = mysqli_num_rows($query);
                                if ($numrows != 0) {
                                    while ($row = mysqli_fetch_array($query)) {
                                       
                                        $nt_id = $row['newtransaction_id'];
                                        $fbarcode = $row['barcode'];
                                        $fdesc = $row['description'];
                                        $fquantity = $row['quantity'];
                                        $fcost = convert($row['cost_per_unit']);
                                        $ftotal = convert($row['total']);

                                        echo "<tr><td>$fbarcode</td>";
                                        echo "<td>$fdesc</td>";
                                        echo "<td>$fquantity</td>";
                                        echo "<td>₱ $fcost</td>";
                                        echo "<td>₱ $ftotal</td>";
                                        echo "<td><a class='btn btn-danger btn-sm' href='removeitem.php?ntid=$nt_id'><i class='glyphicon glyphicon-remove'></i></a></td>";
                                        echo "</tr>";

                                    }
                                    $query2 = mysqli_query($conn, "SELECT SUM(total) as 'grand' FROM newtransaction");
                                    $row2 = mysqli_fetch_array($query2);
                                    $grand = convert($row2['grand']);

                                        echo "<tr><td><strong>TOTAL</strong></td>";
                                        echo "<td></td>";
                                        echo "<td></td>";
                                        echo "<td></td>";
                                        echo "<td><strong>₱ $grand</strong></td></tr>";
                                }
                                else{
                                    ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>

                                    <?php
                                }
                            ?>
                
                        </tbody>
                        </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div><!--/.fluid-container-->

<!-- external javascript -->



<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>
<?php
    include('modals.php');
?>

</body>
</html>
