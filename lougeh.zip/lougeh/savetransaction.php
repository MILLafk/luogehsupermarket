<?php
	session_start();
	include('includes/config.php');

	date_default_timezone_set("Asia/Hong_Kong");
	$timestamp =  date("Y-m-d H:i:s");

	if ($_SESSION['trantype'] == 'Sales') {
		$query = mysqli_query($conn, "SELECT * FROM newtransaction");
		while ($row = mysqli_fetch_array($query)){
			$barcode = $row['barcode'];
			$desc = $row['description'];
			$quantity = $row['quantity'];
			$costperunit = $row['cost_per_unit'];
			$total = $row['total'];
			$customer_id = $_SESSION['id'];

			$sql = "INSERT INTO sales_transaction (transaction_timestamp, customer_id, barcode, quantity, cost_per_unit, total)
					VALUES ('$timestamp', '$customer_id', '$barcode', $quantity, $costperunit, $total)";

			mysqli_query($conn, $sql);

			mysqli_query($conn, "UPDATE items set quantity = quantity - $quantity WHERE barcode = '$barcode'");
		}

	}
	else if ($_SESSION['trantype'] == 'Delivery') {
		$query = mysqli_query($conn, "SELECT * FROM newtransaction");
		while ($row = mysqli_fetch_array($query)){
			$barcode = $row['barcode'];
			$desc = $row['description'];
			$quantity = $row['quantity'];
			$costperunit = $row['cost_per_unit'];
			$total = $row['total'];
			$supplier_id = $_SESSION['id'];

			$sql = "INSERT INTO delivery_transaction (transaction_timestamp, supplier_id, barcode, quantity, cost_per_unit, total)
					VALUES ('$timestamp', '$supplier_id', '$barcode', $quantity, $costperunit, $total)";

			mysqli_query($conn, $sql);

			mysqli_query($conn, "UPDATE items set quantity = quantity + $quantity WHERE barcode = '$barcode'");

		}

	}

	$_SESSION['trantype'] = '';
	$_SESSION['id'] = '';
	$_SESSION['type'] = '';
	$_SESSION['curbar'] = '';

	mysqli_query($conn, 'DELETE FROM newtransaction');

	header('location:index.php');	


?>