<?php
session_start();
include('includes/config.php');

$curbar = $_REQUEST['curbar'];

$_SESSION['curbar'] = $curbar;

header('location:newtransaction.php');


?>